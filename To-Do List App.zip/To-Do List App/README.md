# RIHAD VARIAWA, Data Scientist

![](https://media.giphy.com/media/YLHwkqayc1j7a/giphy.gif)

## To-do List app

### Running the project
1. Ensure that you are in the project home directory. Create the machine learning model by running below command -
```
python3 main.py
```
This would create a serialized version of our model into a file model.pkl